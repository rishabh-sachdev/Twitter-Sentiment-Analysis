from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import json
#consumer key, consumer secret, access token, access secret.
ckey="hgdKXLyQeUUFqSwNVmcvX1Nza"
csecret="Ghp4sDLEODvRQXyfCQ0FVPibwFkIs0CCkqqnyHuWc3uscReKnm"
atoken="4840708046-JZV9tqeD8lG2EWvPQ1A5Siods05n1WkfIyRxdLb"
asecret="JcBm4NGG5rlzxQdygXR30LLh20X8UD9u3FWE65NUni23R"


class listener(StreamListener):

    def on_data(self, data):
        all_data = json.loads(data)
        tweet = all_data["text"].encode('ascii',errors='ignore')
        saveFile = open('Data/twitDB1.csv','wb')
        saveFile.write(tweet)
        saveFile.write(b'\n')
        saveFile.close()
        print(tweet)        
        
        return True

    def on_error(self, status):
        
        print(status)

auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)

twitterStream = Stream(auth, listener())
twitterStream.filter(track=['indian rail', 'indian railways', '@RailMinIndia'])
