import nltk
import re
import string
words = set(nltk.corpus.words.words())
##def rem(text):
##    return "".join([i if ord(i) < 128 else ' ' for i in text])

def processTweet(tweet):
    # process the tweets

   # tweet = tweet[5:].encode('ascii',errors='ignore')
    
    #Convert to lower case
    tweet = tweet.lower()
    tweet=re.sub('rt',' ',tweet)
    #Convert www.* or https?://* to URL
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))',' ',tweet)
    #Convert @username to AT_USER
    tweet = re.sub('@[^\s]+',' ',tweet)
    #Remove additional white spaces
    tweet = re.sub('[\s]+', ' ', tweet)
    #Replace #word with word
    tweet = re.sub(r'#([^\s]+)', r'\1', tweet)
    #trim
    tweet = tweet.strip('\'"')
    #Remove colon
    tweet = re.sub(r'([^\s]+):','', tweet)
    #Remove semicolon
    tweet = re.sub(r'([^\s]+);','.', tweet)
    tweet = re.sub(r'[^\x00-\x7f]',r'', tweet)
    #tweet = rem(tweet)
    return tweet
f1 = open('Data/pre_processed_tweets.csv','w')
with open('Data/tweetText.csv','r') as f:
    for tweet in f:
        tweet = processTweet(tweet)
        print(tweet.encode('ascii','ignore'))
        print('tweet : ' +tweet)
        f1.write(tweet+'\n')
f1.close()


