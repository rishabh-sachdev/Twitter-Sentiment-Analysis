import nltk
from nltk.corpus import wordnet
cleanliness = []
for syn in wordnet.synsets("clean"):
    for l in syn.lemmas():
        cleanliness.append(l.name())
        if l.antonyms():
            cleanliness.append(l.antonyms()[0].name())
cleanliness.extend(["toilet","water","spill"])     #adding some other words manually
print(set(cleanliness))

punctuality = []

for syn in wordnet.synsets("late"):
    for l in syn.lemmas():
        punctuality.append(l.name())
        if l.antonyms():
            punctuality.append(l.antonyms()[0].name())

punctuality.extend(["hours", "delayed", "running", "missed"])

print(set(punctuality))



words = set(nltk.corpus.words.words())
f1 = open('Data/Cleanliness.csv','w')
f2 = open('Data/Punctuality.csv','w')

with open('Data/pre_processed_tweets.csv','r') as f:
    
    for tweet in f:
        c = 0
        p = 0
        tweet1= ""
##        tweet1 = (" ".join(w for w in nltk.wordpunct_tokenize(tweet) \
##             if w.lower() in words or not w.isalpha()))
        for w in nltk.wordpunct_tokenize(tweet):
            #print(w)
            
            if w in words:
                
                tweet1 = tweet1+w+" "
                if w in cleanliness:
                    c=c+1
                elif w in punctuality:
                    p=p+1
        print(tweet1)
        if(c!=0 and c>p):
            f1.write(tweet1)
            f1.write('\n')
        elif(p!=0 and p>c):
            f2.write(tweet1)
            f2.write('\n')
f1.close()
f2.close()

        
