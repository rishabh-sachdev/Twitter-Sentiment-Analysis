
from textblob import TextBlob
  
def get_tweet_sentiment(tweet):
    '''
    Utility function to classify sentiment of passed tweet
    using textblob's sentiment method
    '''
    # create TextBlob object of passed tweet text
    analysis = TextBlob(tweet)
    # set sentiment
    if analysis.sentiment.polarity > 0.6:
        return 'positive'
    elif analysis.sentiment.polarity == 0:
        return 'neutral'
    else:
        return 'negative'
 
def get_tweets(filename):
    tweets = []
    with open(filename,'r') as f:
        for tweet in f:
           # print(tweet)
            tweets.append(tweet)
    # return parsed tweets
    return tweets

def main():
    tweets = get_tweets('Data/Cleanliness.csv')
   # print(tweets)
 
    # picking positive tweets from tweets
    ptweets = [tweet for tweet in tweets if get_tweet_sentiment(tweet) == 'positive']
    # percentage of positive tweets
    print("Positive tweets percentage: ",len(ptweets)/len(tweets))
    # picking negative tweets from tweets
    ntweets = [tweet for tweet in tweets if get_tweet_sentiment(tweet) == 'negative']
    # percentage of negative tweets
    print("Negative tweets percentage: ",len(ntweets)/len(tweets))
    # percentage of neutral tweets
    print("Neutral tweets percentage: ",
        (len(tweets)- len(ntweets) - len(ptweets))/len(tweets))
 
    # printing first 5 positive tweets
    print("\n\nPositive tweets:")
    for tweet in ptweets[:10]:
        print(tweet.encode('ascii',errors='ignore'))
 
    # printing first 5 negative tweets
    print("\n\nNegative tweets:")
    for tweet in ntweets[:10]:
        print(tweet.encode('ascii',errors='ignore'))
 
if __name__ == "__main__":
    # calling main function
    main()
